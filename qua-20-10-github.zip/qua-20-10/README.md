# Website tặng Mẹ và em gái ngày 20/10

## Đăng website miễn phí bằng GitHub Pages
1. Đăng nhập GitHub và tạo repository mới, ví dụ `qua-20-10`.
2. Chọn **Public**, rồi tạo repository.
3. Tải `index.html` lên repository (Add file → Upload files → Commit changes).
4. Vào **Settings → Pages**.
5. Ở **Build and deployment**, chọn **Deploy from a branch**.
6. Chọn branch **main**, folder **/(root)** rồi nhấn **Save**.
7. Đợi một chút, GitHub sẽ hiện đường dẫn website dạng `https://TEN-GITHUB.github.io/qua-20-10/`.

## Cá nhân hóa
Mở `index.html`, tìm và sửa các lời chúc cho giống cách bạn gọi Mẹ/em (ví dụ “con”, “anh” hoặc “chị”). Bạn cũng có thể đổi tiêu đề và thêm ảnh gia đình nếu muốn.
